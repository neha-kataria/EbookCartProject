-- MySQL dump 10.13  Distrib 5.7.12, for linux-glibc2.5 (x86_64)
--
-- Host: localhost    Database: EbookCartProject
-- ------------------------------------------------------
-- Server version	5.7.16-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sub_category`
--

DROP TABLE IF EXISTS `sub_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `parent_category` varchar(45) NOT NULL,
  `path` varchar(45) DEFAULT NULL,
  `display_at` varchar(45) DEFAULT 'show',
  `short_desc` varchar(250) DEFAULT NULL,
  `thumb_name` varchar(45) DEFAULT NULL,
  `thumb_path` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  KEY `fk_sub_category_1_idx` (`parent_category`),
  CONSTRAINT `fk_sub_category_1` FOREIGN KEY (`parent_category`) REFERENCES `category` (`name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_category`
--

LOCK TABLES `sub_category` WRITE;
/*!40000 ALTER TABLE `sub_category` DISABLE KEYS */;
INSERT INTO `sub_category` VALUES (2,'Science fiction','Fiction','/','show','Science fiction is a genre of fiction in which the stories often tell about science and technology of the future.','Science fiction_1479877904898.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/subcategory//'),(3,'Classic','Mystery','/Mystery','show','The childhood series of famous five ,nancy drew, etc','Classic_1479883051093.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/subcategory//'),(6,'autobiography','Biography','/Biography','show','author who writes his own life story','autobiography_1479890115500.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/subcategory//'),(7,'Play','Romance','/Romance','show','A play is a form of literature written by a playwright, usually consisting of dialogue between characters, intended for theatrical performance rather than just reading.','Play_1479890585615.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/subcategory//'),(8,'Short Stories','Romance','/Romance','show','short stories written on true love from real life or heartfelt stories','Short Stories_1479891034140.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/subcategory//'),(9,'Biography','Biography','/Biography','show','an account of someone\'s life written by someone else.','Biography_1479892206405.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/subcategory//'),(10,'Historical Fiction','Fiction','/Fiction','show','novels in which a story is made up but is set in the past and sometimes borrows true characteristics of the time period in which it is set. ','Historical Fiction_1479893141836.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/subcategory//'),(11,'java','educational','/educational','show','java','java_1480590117113.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/subcategory//'),(12,'Crime','Mystery','/Mystery','hide','real time crime based stories','Crime_1481475936373.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/subcategory//'),(15,'Indian Mythology','Mythology','/Mythology','show','India being rich in culture with different gods and goddesses, here are some tales about them','Indian Mythology_1481478507118.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/subcategory//'),(16,'b','a','/a','show','dcadcfad','b_1481484761944.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/subcategory//'),(17,'kk','qaz','/qaz','show','xshxsjxisjax','nothumb.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/subcategory//');
/*!40000 ALTER TABLE `sub_category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-13 17:35:29
