-- MySQL dump 10.13  Distrib 5.7.12, for linux-glibc2.5 (x86_64)
--
-- Host: localhost    Database: EbookCartProject
-- ------------------------------------------------------
-- Server version	5.7.16-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `parent_category` varchar(45) NOT NULL,
  `path` varchar(45) NOT NULL,
  `display_at` varchar(45) DEFAULT 'show',
  `thumb_name` varchar(45) DEFAULT NULL,
  `thumb_path` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Fiction','Root','/','show','Fiction_1479814378192.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/category//'),(2,'Biography','Root','/','show','Biography_1479814440842.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/category//'),(3,'Mystery','Root','/','show','Mystery_1479877463214.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/category//'),(4,'Romance','Root','/','show','Romance_1479877543589.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/category//'),(5,'educational','Root','/','show','educational_1480590083184.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/category//'),(8,'References','Root','/','show','References_1481475787729.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/category//'),(9,'Mythology','Root','/','show','Mythology_1481478160261.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/category//'),(10,'xyz','Root','/','show','xyz_1481484428936.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/category//'),(11,'x','Root','/','show','x_1481484585959.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/category//'),(12,'a','Root','/','show','a_1481484701730.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/category//'),(13,'General Awareness','Root','/','show','General Awareness_1481526349527.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/category//'),(17,'abc','Root','/','show','nothumb','/home/neha/NetBeansProjects/ebook_thumbnails/category//'),(18,'wxyz','Root','/','show','nothumb.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/category//'),(19,'qaz','Root','/','show','qaz_1481528959986.jpg','/home/neha/NetBeansProjects/ebook_thumbnails/category//');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-13 17:35:29
